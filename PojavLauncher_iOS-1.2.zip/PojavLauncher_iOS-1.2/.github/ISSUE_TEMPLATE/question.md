---
name: Question
about: Want to learn more about PojavLauncher?
title: "[Question]"
labels: question
assignees: ''

---

To use this template:
* CHECK OTHER ISSUES and see if anyone else has asked the same question. We will close any duplicate requests.
* Don't delete any of the words between asterisks.
* Add a key part of the question to the title (ex. [Question] Does Zink work?)
* Follow all of the steps. If you do not provide an answer to each section in this template, the issue will be closed.

// Delete this line and the above text before submitting.

**Ask your question here!**
Be descriptive in your question so that we can provide an equally descriptive answer. Make sure you’ve checked out the subreddit or the README before asking—your question might already have an answer.
