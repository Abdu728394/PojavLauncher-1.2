package net.kdt.pojavlaunch.value.launcherprofiles;

public class MinecraftResolution
{
	public int width;
	public int height;
}
