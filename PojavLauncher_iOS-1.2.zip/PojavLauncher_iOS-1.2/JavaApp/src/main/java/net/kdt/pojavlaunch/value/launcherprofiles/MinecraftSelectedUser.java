package net.kdt.pojavlaunch.value.launcherprofiles;

public class MinecraftSelectedUser
{
	public String account;
	public String profile;
}
