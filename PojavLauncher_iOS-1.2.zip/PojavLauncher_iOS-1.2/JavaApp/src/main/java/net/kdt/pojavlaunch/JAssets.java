package net.kdt.pojavlaunch;

import java.util.Map;

public class JAssets {
    public boolean map_to_resources;
    public Map<String, JAssetInfo> objects;
}

