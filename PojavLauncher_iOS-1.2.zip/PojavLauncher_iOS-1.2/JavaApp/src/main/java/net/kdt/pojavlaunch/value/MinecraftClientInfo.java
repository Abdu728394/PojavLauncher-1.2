package net.kdt.pojavlaunch.value;

public class MinecraftClientInfo
{
	public String sha1;
	public int size;
	public String url;
}
