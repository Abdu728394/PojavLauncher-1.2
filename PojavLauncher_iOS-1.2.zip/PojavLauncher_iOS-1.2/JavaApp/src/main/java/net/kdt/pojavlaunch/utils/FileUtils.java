package net.kdt.pojavlaunch.utils;

public class FileUtils
{
}