package net.kdt.pojavlaunch.uikit;

public interface UIKitCallback {
    public void onCallback();
}
