package org.lwjgl.opengl;

public class EXTTextureRectangle {
	public final static int GL_MAX_RECTANGLE_TEXTURE_SIZE_EXT = 34040;
	public final static int	GL_PROXY_TEXTURE_RECTANGLE_EXT = 34039;
	public final static int	GL_TEXTURE_BINDING_RECTANGLE_EXT = 34038;
	public final static int	GL_TEXTURE_RECTANGLE_EXT = 34037;
}
