package com.mojang.text2speech;

public class NarratorWindows extends NarratorDummy {
}
