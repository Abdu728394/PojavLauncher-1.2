package com.mojang.text2speech;

public class NarratorLinux extends NarratorDummy {
}