package com.mojang.text2speech;

public class NarratorOSX extends NarratorDummy {
}
