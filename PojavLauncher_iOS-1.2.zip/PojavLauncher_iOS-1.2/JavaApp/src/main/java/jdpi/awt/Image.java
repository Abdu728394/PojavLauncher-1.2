package jdpi.awt;

public abstract class Image {
    
}
