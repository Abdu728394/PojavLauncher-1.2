package jdpi.awt.event;

public interface WindowListener {
}