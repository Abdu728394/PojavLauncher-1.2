package jdpi.awt;
public class GraphicsEnvironment {
	public static boolean isHeadless() {
		return true;
	}
}
