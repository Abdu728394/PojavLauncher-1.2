package jdpi.awt;

public class BorderLayout extends LayoutManager {
}
