package jdpi.awt;

public class Frame extends Window {
    public Frame(String title) {
    	super(title);
	}
}