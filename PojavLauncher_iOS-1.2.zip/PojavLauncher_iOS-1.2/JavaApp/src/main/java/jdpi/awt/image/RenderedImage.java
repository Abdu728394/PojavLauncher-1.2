package jdpi.awt.image;

public interface RenderedImage {
}