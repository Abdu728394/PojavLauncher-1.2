package jdpi.awt;

public class Container extends Component {
	public void add(Component component, Object something) {
	}
	
    public void setLayout(LayoutManager mgr) {
	}
}
