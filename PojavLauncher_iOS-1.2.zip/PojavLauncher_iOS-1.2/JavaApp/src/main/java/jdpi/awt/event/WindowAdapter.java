package jdpi.awt.event;

public class WindowAdapter implements WindowListener {
}