package jdpi.awt.image;

public class DataBuffer {
    
}
