package jdpi.awt;

public class Graphics2D extends Graphics {
    public Graphics2D(java.awt.Graphics2D g2d) {
        super(g2d);
    }
}
