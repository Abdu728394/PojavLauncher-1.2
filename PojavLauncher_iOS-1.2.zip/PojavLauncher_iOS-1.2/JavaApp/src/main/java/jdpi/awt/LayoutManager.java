package jdpi.awt;

public class LayoutManager {
}
