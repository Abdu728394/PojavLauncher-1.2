package jdpi.awt;

import jdpi.awt.event.*;

public class Window extends Container {
    public Window(String title) {
	}
	
	public void addWindowListener(WindowListener listener) {
	}

    public void pack() {
	}
	
	public void setLocationRelativeTo(Component comp) {
	}
}
