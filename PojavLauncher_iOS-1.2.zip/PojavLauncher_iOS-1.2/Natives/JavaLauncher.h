#pragma once

#include <stdbool.h>

static bool started = false;

int launchJVM(int argc, char *argv[]);
int launchUI(int argc, char *argv[]);
