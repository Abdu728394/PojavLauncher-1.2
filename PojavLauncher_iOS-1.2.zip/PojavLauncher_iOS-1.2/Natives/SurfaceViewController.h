#import <UIKit/UIKit.h>
#import "MGLKit.h"

MGLKView *glView;

@interface SurfaceViewController : MGLKViewController
// MGLKViewController
// UIViewController

@end
