#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
- (void)enterLauncher;
@end

@interface LoginListViewController : UITableViewController

@end

